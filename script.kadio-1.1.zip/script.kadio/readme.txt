---=== ReadMe ===---

You MUST have a DVB-T tuner to make this work!

---=== Instructions ===---

1. Boot with DVB-T card inserted.
2. Install ZIP file of this file's directory inside Kodi
3. Click Yes
4. Station and Decimal - If the station is 103.3 type 103 in the first box, 3 in the second box, 
   hit ok and it should tune to the selected frequency and play sound.
5. Click app again under Addons to and click No to stop radio playback.

Install the zip file and cross fingers...

---=== Tested setups ===---

1. Rasperry Pi 3+ running OSMC in Kodi 18.5 with a NooElec R820T USB Adapter.
